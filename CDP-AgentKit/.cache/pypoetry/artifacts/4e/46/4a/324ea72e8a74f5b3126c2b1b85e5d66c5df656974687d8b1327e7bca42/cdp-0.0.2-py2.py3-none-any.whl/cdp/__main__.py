from .cdp import main

main()

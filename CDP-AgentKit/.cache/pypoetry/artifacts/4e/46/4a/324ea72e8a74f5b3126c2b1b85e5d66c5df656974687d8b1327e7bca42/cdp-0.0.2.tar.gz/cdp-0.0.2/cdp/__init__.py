from pkg_resources import get_distribution

__project__ = 'cdp'
__version__ = get_distribution(__project__).version

"""Specifies package level constants used throughout the package."""

# SDK_DEFAULT_SOURCE (str): Denotes the default source for the Python SDK.
SDK_DEFAULT_SOURCE = "sdk"

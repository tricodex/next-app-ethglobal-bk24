"""Chain for question-answering against a vector database."""

from cdp_langchain.__version__ import __version__

__all__ = ["__version__"]

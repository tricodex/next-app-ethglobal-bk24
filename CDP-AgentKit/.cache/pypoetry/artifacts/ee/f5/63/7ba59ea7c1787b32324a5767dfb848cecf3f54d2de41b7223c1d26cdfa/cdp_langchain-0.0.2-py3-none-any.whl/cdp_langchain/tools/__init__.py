"""CDP Tool."""

from cdp_langchain.tools.cdp_tool import CdpTool

__all__ = ["CdpTool"]
